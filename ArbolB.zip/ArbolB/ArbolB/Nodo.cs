﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArbolB
{
    class Nodo
    {
        public int valor1 { get; set; }

        public int valor2 { get; set; }

        public int valor3 { get; set; }

        public int valor4 { get; set; }

        public int valor5 { get; set; }

        public SimulacionArbol Izquierda { get; set; }

        public SimulacionArbol Derecha { get; set; }

        public Nodo Anterior { get; set; }
    }
}
