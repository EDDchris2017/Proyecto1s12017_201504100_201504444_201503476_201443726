﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArbolB
{
    class SimulacionArbol
    {
        public Nodo raiz = null;
        public SimulacionArbol() {
            Nodo raiz = new Nodo();
            
        }
        
        public void insertar(int entra) {

            if (raiz== null)
            {
                    Nodo nuevo = new Nodo();
                if (nuevo.valor1==0)
                {
                    nuevo.valor1 = entra;
                }
                else
                {
                    if (nuevo.valor2 == 0)
                    {
                        nuevo.valor2 = entra;
                    }
                    else
                    {
                        if (nuevo.valor3 == 0)
                        {
                            nuevo.valor3 = 0;
                        }
                    }
                    
                }
                 
                    nuevo.Derecha = new SimulacionArbol();
                    nuevo.Izquierda = new SimulacionArbol();
                    raiz = nuevo;
                    Console.WriteLine("");
                    Console.WriteLine("");
                    //Console.WriteLine("----------------------------------------------");
                    //Console.WriteLine("|                 Valor Entrante: " + raiz.valor1 + "              |");
                    //Console.WriteLine("----------------------------------------------");
                    Console.WriteLine(raiz.valor1 + " , " + raiz.valor2 + " , " + raiz.valor3 + " , " + raiz.valor4 + " , " + raiz.valor5);
                
            }
            else
            {
                //Console.WriteLine(raiz.valor1 + " , " + raiz.valor2 + " , " + raiz.valor3 + " , " + raiz.valor4 + " , " + raiz.valor5);

                if (entra > raiz.valor1)
                    {
                        //(raiz.Derecha).insertar(entra);
                        raiz.valor2 = entra;
                    }
                    if (entra < raiz.valor1)
                    {
                    //(raiz.Izquierda).insertar(entra);
                    raiz.valor3 = entra;
                    }
            }
            
        }

        public void preOrder()
        {
            if (raiz != null)
            {
                Console.WriteLine("(" + raiz.valor1 + raiz.valor2 + raiz.valor3 + raiz.valor4 + raiz.valor5 + ")" + " -> ");
                raiz.Izquierda.preOrder();
                raiz.Derecha.preOrder();
            }
        }

        public void inOrder()
        {
            if (raiz != null)
            {
                
                raiz.Izquierda.inOrder();
                Console.WriteLine("(" + raiz.valor1 + raiz.valor2 + raiz.valor3 + raiz.valor4 + raiz.valor5 + ")" + " -> ");
                raiz.Derecha.inOrder();
            }
        }
        

    }
}
