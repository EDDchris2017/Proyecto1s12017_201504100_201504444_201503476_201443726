﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace ArbolB
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        
        static void Main(string[] args)
        {
            Console.WriteLine("------------------------ INICIO DE ARBOL B ----------------------------");

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            Console.WriteLine("");
            Console.WriteLine("------------------------ INICIO DEL ARBOL ----------------------------");
            Console.WriteLine("");
            //ImprimirArbol(SimulacionArbol.RaizDerecha, string.Empty);
            Console.WriteLine("");
            Console.WriteLine("------------------------ FIN DEL ARBOL ----------------------------");
            Console.WriteLine("");

            
            
        }
        /*
        public static void ImprimirArbol(Nodo raiz, string indent)
        {
            if (raiz.Izquierda != null)
            {
                ImprimirArbol(raiz.Izquierda, indent + "        \t");
            }

            Console.WriteLine(indent + raiz.valor);
           
            if (raiz.Derecha != null)
            {
                ImprimirArbol(raiz.Derecha, indent + "            \t");
            }
            
        }*/

    }
}
