﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ArbolB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string contador="";
        SimulacionArbol enviar = new SimulacionArbol();
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (contador=="")
            {
                contador = richTextBox1.Text;
            }
            else
            {
                contador = contador + " , " + richTextBox1.Text;
            }

            //Nodo enviarDato = new Nodo() { valor=int.Parse(richTextBox1.Text) };
            enviar.insertar(int.Parse(richTextBox1.Text));
            
            label1.Text = contador;
            richTextBox1.Text = "";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            enviar.inOrder();
        }
    }
}
